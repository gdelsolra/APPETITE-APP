package com.example.finalprojectappetitelab;

public class Item {
    private int id;
    private String name;
    private String expirationDate;

    public Item(String name, String expirationDate) {
        this.name = name;
        this.expirationDate = expirationDate;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getExpirationDate() { return expirationDate; }
    public void setExpirationDate(String expirationDate) { this.expirationDate = expirationDate; }
}
