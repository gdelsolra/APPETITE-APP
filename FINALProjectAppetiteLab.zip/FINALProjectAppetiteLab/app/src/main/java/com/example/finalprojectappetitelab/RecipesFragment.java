package com.example.finalprojectappetitelab;

import androidx.fragment.app.Fragment;

public class RecipesFragment extends Fragment {
}
