package com.example.finalprojectappetitelab;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

/**
 * HomeActivity serves as the main screen after the user logs in.
 * It contains a bottom navigation bar for navigating between different fragments:
 * CalendarExpirationFragment, RecipesFragment, InventoryFragment, and MoreFragment.
 * The activity loads the CalendarExpirationFragment by default.
 */
public class HomeActivity extends AppCompatActivity {

    /**
     * Called when the activity is first created.
     * Initializes the bottom navigation bar and sets up the initial fragment.
     *
     * @param savedInstanceState Contains data from the activity's previous instance (if any).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize the BottomNavigationView component that allows fragment navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set the navigation item selection listener for handling fragment switching
        bottomNavigationView.setOnItemSelectedListener(navListener);

        // Load the default fragment (CalendarExpirationFragment) when the activity starts
        if (savedInstanceState == null) {
            // Begin a fragment transaction to load CalendarExpirationFragment
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new CalendarExpirationFragment())
                    .commit();
        }
    }

    /**
     * Called when a navigation item is selected.
     * Switches the displayed fragment based on the selected item.
     *
     * @param item The selected menu item.
     * @return true if the fragment change was handled successfully.
     */
    private NavigationBarView.OnItemSelectedListener navListener = new NavigationBarView.OnItemSelectedListener() {


        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment = null; // Holds the fragment to display

            // Determine the fragment to display based on the selected item ID
            int itemId = item.getItemId();
            if (itemId == R.id.nav_calendar) {
                // Load CalendarExpirationFragment for calendar navigation item
                selectedFragment = new CalendarExpirationFragment();
            } else if (itemId == R.id.nav_recipes) {
                // Load RecipesFragment for recipes navigation item
                selectedFragment = new RecipesFragment();
            } else if (itemId == R.id.nav_inventory) {
                // Load InventoryFragment for inventory navigation item
                selectedFragment = new InventoryFragment();
            } else if (itemId == R.id.nav_more) {
                // Load MoreFragment for "more" navigation item
                selectedFragment = new MoreFragment();
            }

            // Check if a fragment was selected, then replace the current fragment
            if (selectedFragment != null) {
                // Begin a fragment transaction to replace the fragment in fragment_container
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selectedFragment)
                        .commit(); // Commit the transaction to apply changes
            }
            return true; // Indicate the selection was handled
        }

    };
}
