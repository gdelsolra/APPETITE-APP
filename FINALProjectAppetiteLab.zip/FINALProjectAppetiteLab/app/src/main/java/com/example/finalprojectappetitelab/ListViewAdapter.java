package com.example.finalprojectappetitelab;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

/**
 * Custom ArrayAdapter to display inventory items in a ListView with options
 * to copy, remove, or edit each item. This adapter communicates with
 * InventoryFragment to perform actions on items.
 */
public class ListViewAdapter extends ArrayAdapter<String> {

    // List of items to be displayed in the ListView
    private ArrayList<String> list;
    private Context context;
    private InventoryFragment fragment; // Reference to InventoryFragment to interact with it

    /**
     * Constructor for the ListViewAdapter.
     *
     * @param context The context in which the adapter is used.
     * @param items The list of items to display.
     * @param fragment The fragment instance to interact with for item actions.
     */
    public ListViewAdapter(Context context, ArrayList<String> items, InventoryFragment fragment) {
        super(context, R.layout.list_row, items);
        this.context = context;
        this.list = items;
        this.fragment = fragment; // Assigns the fragment reference to interact with it
    }

    /**
     * Provides a view for an adapter view (ListView) for each item in the list.
     *
     * @param position The position of the item in the data set.
     * @param convertView The old view to reuse, if possible.
     * @param parent The parent view that this view will be attached to.
     * @return The View for the item at the specified position.
     */
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;

        // Check if the view already exists; if not, inflate a new view from the layout
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_row, parent, false);

            // Initialize the ViewHolder to cache the views for quicker access
            holder = new ViewHolder();
            holder.number = convertView.findViewById(R.id.number); // Displays item position number
            holder.name = convertView.findViewById(R.id.name); // Displays item name
            holder.copy = convertView.findViewById(R.id.copy); // "Copy" button to duplicate item
            holder.remove = convertView.findViewById(R.id.remove); // "Remove" button to delete item
            holder.edit = convertView.findViewById(R.id.edit); // "Edit" button to modify expiration date

            // Store the ViewHolder in the convertView for future reuse
            convertView.setTag(holder);
        } else {
            // Retrieve the existing ViewHolder from convertView
            holder = (ViewHolder) convertView.getTag();
        }

        // Set up the item display:
        // 1. Display the item position (starting from 1) with a dot (e.g., "1. ItemName")
        holder.number.setText((position + 1) + ".");
        // 2. Set the item's name from the list
        holder.name.setText(list.get(position));

        // Set up "Copy" button functionality:
        // Calls the addItem method in InventoryFragment to duplicate the item.
        // Default expiration date is set to "N/A" if not available.
        holder.copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Extract the expiration date if it's available
                String itemText = list.get(position);
                String expirationDate = "N/A"; // Default to "N/A"

                // Check if the item text contains an expiration date and extract it
                if (itemText.contains("(Expires: ")) {
                    int startIndex = itemText.indexOf("(Expires: ") + 10;
                    int endIndex = itemText.indexOf(")", startIndex);
                    expirationDate = itemText.substring(startIndex, endIndex); // Get the actual date
                }

                // Call addItem with the existing expiration date or default to "N/A"
                fragment.addItem(list.get(position).split(" \\(")[0], expirationDate);
            }
        });

        // Set up "Remove" button functionality:
        // Calls the removeItem method in InventoryFragment to delete the item at this position.
        holder.remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment.removeItem(position); // Remove item at the specified position
            }
        });

        // Set up "Edit" button functionality:
        // Calls the modifyExpirationDate method in InventoryFragment to change the item's expiration date.
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment.modifyExpirationDate(position); // Edit expiration date of item at the position
            }
        });

        return convertView; // Return the fully populated view for the current item
    }

    /**
     * Static ViewHolder class to hold views for each item in the list.
     * This helps in optimizing ListView performance by reducing the number of findViewById calls.
     */
    static class ViewHolder {
        TextView number; // Displays item position number
        TextView name; // Displays item name
        ImageView copy; // Copy button to duplicate item
        ImageView remove; // Remove button to delete item
        ImageView edit; // Edit button to modify expiration date
    }
}
