package com.example.finalprojectappetitelab;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class CalendarExpirationFragment extends Fragment {

    private CalendarView calendarView;
    private ListView expirationListView;
    private dbConnect dbHelper;
    private ArrayAdapter<String> expirationAdapter;
    private List<String> expirationItems;
    private int userId; // User ID to fetch the user's phone number
    private boolean smsPermissionGranted = false; // Track if SMS permission is granted

    // ActivityResultLauncher to handle the SMS permission request
    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    smsPermissionGranted = true;
                    Toast.makeText(getActivity(), "SMS permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    smsPermissionGranted = false;
                    Toast.makeText(getActivity(), "SMS permission denied. SMS notifications will not work.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new dbConnect(getContext());

        // Check and request SMS permission
        checkAndRequestSmsPermission();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_calendar_expiration, container, false);

        calendarView = view.findViewById(R.id.calendarView);
        expirationListView = view.findViewById(R.id.expirationListView);

        // Retrieve userId from arguments or saved instance (passed from previous activity)
        userId = getArguments() != null ? getArguments().getInt("userId", -1) : -1;

        calendarView.setOnDateChangeListener((view1, year, month, dayOfMonth) -> {
            String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;
            loadExpiringItems(selectedDate);
        });

        return view;
    }

    /**
     * Checks if SMS permission is granted, and requests it if not.
     * If permission is denied, sets smsPermissionGranted to false.
     */
    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsPermissionGranted = true;
        } else {
            requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    /**
     * Loads items that are near expiration for the selected date.
     * @param date The selected date in the format "yyyy-MM-dd".
     */
    private void loadExpiringItems(String date) {
        List<Item> items = dbHelper.getItemsNearExpiration(date);
        expirationItems = new ArrayList<>();

        for (Item item : items) {
            expirationItems.add(item.getName() + " expires on " + item.getExpirationDate());
            if (smsPermissionGranted) {
                sendExpirationSMS(item); // Send SMS only if permission is granted
            }
        }

        expirationAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, expirationItems);
        expirationListView.setAdapter(expirationAdapter);
    }

    /**
     * Sends an SMS reminder to the user when an item is near its expiration date.
     * Only called if SMS permission is granted.
     *
     * @param item The item nearing expiration.
     */
    private void sendExpirationSMS(Item item) {
        // Retrieve the user's phone number (update this method as needed to fetch from database or user object)
        String userPhoneNumber = dbHelper.getUserPhoneNumber(String.valueOf(userId));
        String message = "Reminder: " + item.getName() + " is expiring on " + item.getExpirationDate();

        if (userPhoneNumber != null && !userPhoneNumber.isEmpty()) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(userPhoneNumber, null, message, null, null);
                Toast.makeText(getActivity(), "SMS reminder sent for " + item.getName(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(getActivity(), "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(getActivity(), "User phone number not available.", Toast.LENGTH_SHORT).show();
        }
    }

}
