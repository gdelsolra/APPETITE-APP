package com.example.finalprojectappetitelab;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Fragment to manage the user's inventory.
 * Allows adding, deleting, and modifying items with expiration dates.
 */
public class InventoryFragment extends Fragment {

    private ListView listView;
    private ArrayList<String> items;
    private ListViewAdapter listAdapter; // Custom adapter for handling item interactions
    private EditText add_item_text, add_item_expiration;
    private ImageView enter;
    private CheckBox freshProduceCheckbox;
    private dbConnect dbHelper;
    private Toast t;
    private int userId; // Stores the ID of the logged-in user

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new dbConnect(getActivity());

        // Retrieve the user ID passed from the parent activity
        if (getArguments() != null) {
            userId = getArguments().getInt("userId", -1);
        }
    }

    /**
     * Inflates the layout for this fragment and initializes UI elements.
     *
     * @param inflater LayoutInflater to inflate the fragment view
     * @param container ViewGroup that contains the fragment's UI
     * @param savedInstanceState Bundle with saved state data (if any)
     * @return View representing the fragment layout
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);

        // Initialize UI components
        listView = view.findViewById(R.id.listview);
        add_item_text = view.findViewById(R.id.add_item_text);
        add_item_expiration = view.findViewById(R.id.add_item_expiration);
        enter = view.findViewById(R.id.add);
        freshProduceCheckbox = view.findViewById(R.id.fresh_produce_checkbox);

        items = new ArrayList<>();

        // Initialize the custom adapter with the current items list
        listAdapter = new ListViewAdapter(getActivity(), items, this);
        listView.setAdapter(listAdapter); // Set custom adapter to ListView

        loadItems(); // Load items after setting the adapter

        // Toggle expiration date input based on "Fresh Produce" checkbox
        freshProduceCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            add_item_expiration.setEnabled(!isChecked); // Disable date if it's fresh produce
            if (isChecked) {
                add_item_expiration.setText(""); // Clear date if checkbox is checked
            }
        });

        // Handle "Enter" button click to add a new item
        enter.setOnClickListener(v -> {
            String itemName = add_item_text.getText().toString();
            String expirationDate = add_item_expiration.getText().toString();

            // Validate that item name is entered
            if (itemName.isEmpty()) {
                makeToast("Please enter an item name");
            } else {
                boolean isFreshProduce = freshProduceCheckbox.isChecked();
                if (isFreshProduce) {
                    expirationDate = "N/A"; // Set expiration date to "N/A" for fresh produce
                }

                addItem(itemName, expirationDate); // Add item to list and database
                makeToast("Added " + itemName + (isFreshProduce ? " (Fresh Produce)" : ""));

                // Clear input fields
                add_item_text.setText("");
                add_item_expiration.setText("");
                freshProduceCheckbox.setChecked(false);
                loadItems(); // Refresh the list after adding
            }
        });

        return view;
    }

    /**
     * Loads items from the database for the specific user and populates the ListView.
     */
    private void loadItems() {
        List<Item> dbItems = dbHelper.getUserItems(userId); // Fetch items from the database for the specific user
        items.clear();

        // Convert each Item object to a String representation for display
        for (Item item : dbItems) {
            String itemString = item.getName() +
                    (item.getExpirationDate().equals("N/A") ?
                            " (Fresh Produce)" :
                            " (Expires: " + item.getExpirationDate() + ")");
            items.add(itemString);
        }

        // Check if listAdapter is initialized before calling notifyDataSetChanged
        if (listAdapter != null) {
            listAdapter.notifyDataSetChanged(); // Notify adapter of data change
        } else {
            Log.e("InventoryFragment", "listAdapter is null in loadItems()");
        }
    }

    /**
     * Removes an item from the list and database for the specific user.
     *
     * @param position The index of the item in the list to be removed.
     */
    public void removeItem(int position) {
        String itemName = items.get(position).split(" \\(")[0]; // Extract item name without expiration info
        dbHelper.deleteItem(itemName, userId); // Delete item from the database for the specific user
        items.remove(position); // Remove item from the list
        listAdapter.notifyDataSetChanged(); // Update the ListView
        makeToast("Item removed successfully");
    }

    /**
     * Adds a new item to the list and database for the specific user.
     *
     * @param item The name of the item to be added.
     * @param expirationDate The expiration date of the item, or "N/A" if it's fresh produce.
     */
    public void addItem(String item, String expirationDate) {
        String itemString = item +
                (expirationDate.equals("N/A") ?
                        " (Fresh Produce)" :
                        " (Expires: " + expirationDate + ")");

        if (dbHelper.addItem(userId, item, expirationDate)) {
            items.add(itemString); // Add item to the list
            listAdapter.notifyDataSetChanged(); // Update ListView
            makeToast("Item added successfully");
        } else {
            makeToast("Error adding item to database");
        }
    }

    /**
     * Modifies the expiration date of an existing item.
     *
     * @param position The index of the item to modify.
     */
    public void modifyExpirationDate(int position) {
        String itemName = items.get(position).split(" \\(")[0]; // Get the item name

        // Inflate the dialog layout
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_edit_expiration, null);
        EditText editExpirationDate = dialogView.findViewById(R.id.edit_expiration_date);
        Button saveButton = dialogView.findViewById(R.id.save_button);
        Button cancelButton = dialogView.findViewById(R.id.cancel_button);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        saveButton.setOnClickListener(v -> {
            String newExpirationDate = editExpirationDate.getText().toString();
            if (!newExpirationDate.isEmpty()) {
                if (dbHelper.updateItemExpiration(itemName, newExpirationDate, userId)) {
                    makeToast("Expiration date updated for " + itemName);
                    loadItems(); // Refresh the list with the updated expiration date
                } else {
                    makeToast("Error updating expiration date");
                }
                dialog.dismiss();
            } else {
                makeToast("Please enter a new expiration date");
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show(); // Show the dialog
    }


    /**
     * Displays a Toast message on the screen.
     *
     * @param s The message to be displayed.
     */
    private void makeToast(String s) {
        if (t != null) t.cancel(); // Cancel any existing Toast
        t = Toast.makeText(getActivity(), s, Toast.LENGTH_SHORT); // Show new Toast message
        t.show();
    }
}
