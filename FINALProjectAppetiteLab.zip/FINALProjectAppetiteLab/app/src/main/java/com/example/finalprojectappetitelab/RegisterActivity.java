package com.example.finalprojectappetitelab;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalprojectappetitelab.databinding.ActivityRegisterBinding;

public class RegisterActivity extends AppCompatActivity {

    ActivityRegisterBinding binding;
    dbConnect dbHelper;
    EditText edtEmailAddressReg, edtFullNameReg, edtPasswordReg, edtPhoneNumberReg;
    Button btnRegisterReg, btnLoginReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize database helper
        dbHelper = new dbConnect(this);

        // Initialize EditTexts
        edtEmailAddressReg = findViewById(R.id.edtEmailAddressReg);
        edtFullNameReg = findViewById(R.id.edtFullNameReg);
        edtPasswordReg = findViewById(R.id.edtPasswordReg);
        edtPhoneNumberReg = findViewById(R.id.edtPhoneNumberReg);

        // Initialize Buttons
        btnRegisterReg = findViewById(R.id.btnRegisterReg);
        btnLoginReg = findViewById(R.id.btnLoginReg);

        // Set up the Register button click listener
        btnRegisterReg.setOnClickListener(view -> {
            String strFullName = edtFullNameReg.getText().toString().trim();
            String strEmailAddress = edtEmailAddressReg.getText().toString().trim();
            String strPassword = edtPasswordReg.getText().toString().trim();
            String strPhoneNumber = edtPhoneNumberReg.getText().toString().trim();

            // Check for empty fields
            if (strEmailAddress.isEmpty() || strPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the user already exists
            boolean checkUserEmail = dbHelper.checkEmail(strEmailAddress);
            if (!checkUserEmail) {
                // Add the user to the database
                boolean insert = dbHelper.addUser(strFullName, strEmailAddress, strPassword, strPhoneNumber);
                if (insert) {
                    Toast.makeText(RegisterActivity.this, "Signup Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(RegisterActivity.this, "Signup failed", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(RegisterActivity.this, "User already exists, please login", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up the Login button click listener
        btnLoginReg.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });
    }
}
