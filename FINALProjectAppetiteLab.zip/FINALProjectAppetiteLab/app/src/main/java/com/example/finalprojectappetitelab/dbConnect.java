package com.example.finalprojectappetitelab;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class dbConnect extends SQLiteOpenHelper {

    private static final String dbName = "AppetiteLabManager.db";
    private static final int dbVersion = 2;

    // Constructor
    public dbConnect(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    // User Table Columns
    private static final String TABLE_USERS = "users";
    private static final String ID = "id";
    private static final String fullname = "fullname";
    private static final String emailAddress = "emailAddress";
    private static final String password = "password";
    private static final String phoneNumber = "phoneNumber";

    // Item Table Columns
    private static final String TABLE_ITEMS = "items";
    private static final String item_id = "item_id";
    private static final String name = "name";
    private static final String expirationDate = "expirationDate";
    private static final String userId = "user_id";  // Foreign key to link items to users

    /**
     * Called when the database is created for the first time.
     * Creates tables for users and items, with foreign key linking items to specific users.
     *
     * @param MyDatabase SQLiteDatabase instance used to execute SQL commands.
     */
    @Override
    public void onCreate(SQLiteDatabase MyDatabase) {
        String CreateUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                fullname + " TEXT, " +
                emailAddress + " TEXT UNIQUE, " +
                password + " TEXT, " +
                phoneNumber + " TEXT)";
        MyDatabase.execSQL(CreateUserTable);

        String createItemTable = "CREATE TABLE " + TABLE_ITEMS + " (" +
                item_id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                name + " TEXT, " +
                expirationDate + " TEXT, " +
                userId + " INTEGER, " +
                "FOREIGN KEY(" + userId + ") REFERENCES " + TABLE_USERS + "(" + ID + "))";
        MyDatabase.execSQL(createItemTable);
    }

    /**
     * Called when the database needs to be upgraded.
     * Drops old tables and recreates them.
     *
     * @param MyDatabase SQLiteDatabase instance used to execute SQL commands.
     * @param oldVersion old database version number.
     * @param newVersion new database version number.
     */
    @Override
    public void onUpgrade(SQLiteDatabase MyDatabase, int oldVersion, int newVersion) {
        MyDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        MyDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(MyDatabase);
    }

    /**
     /**
     * Adds a new user to the database.
     *
     * @param fullname User's full name.
     * @param email User's email address.
     * @param password User's password.
     * @param phoneNumber User's phone number.
     * @return true if the user was successfully added, false otherwise.
     */
    public boolean addUser(String fullname, String email, String password, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(this.fullname, fullname);
        values.put(this.emailAddress, email);
        values.put(this.password, password);
        values.put(this.phoneNumber, phoneNumber);

        long result = db.insert(TABLE_USERS, null, values); // Insert the new user
        db.close();
        return result != -1; // Return true if insertion was successful
    }

    /**
     * Getter method to obtain the user's phone number from the database
     *
     * @param ID The user ID to search for
     * @return The user's phone number, or null if not found
     */
    public String getUserPhoneNumber(String ID) {
        SQLiteDatabase db = this.getReadableDatabase();
        String phoneNumber = null;

        // Query to select the phone number from the database based on user ID
        Cursor cursor = db.rawQuery("SELECT phoneNumber FROM " + TABLE_USERS + " WHERE ID = ?", new String[]{ID});

        if (cursor.moveToFirst()) {
            // Assuming the phone number is in the first column of the result
            phoneNumber = cursor.getString(0);
        }

        cursor.close();
        db.close();

        return phoneNumber;
    }


    /**
     * Checks if a user with the given email exists in the database.
     *
     * @param email User's email address.
     * @return true if the email exists, false otherwise.
     */
    public boolean checkEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + emailAddress + " = ?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    /**
     * Retrieves the user ID associated with the given email.
     *
     * @param email User's email address.
     * @return The user's ID if found, -1 if the user does not exist.
     */
    public int getUserId(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + ID + " FROM " + TABLE_USERS + " WHERE " + emailAddress + " = ?", new String[]{email});
        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return userId;
    }

    /**
     * Adds a new item to the database for a specific user.
     *
     * @param userId The user's ID who owns the item.
     * @param itemName Name of the item.
     * @param expirationDate Expiration date of the item.
     * @return true if the item was successfully added, false otherwise.
     */
    public boolean addItem(int userId, String itemName, String expirationDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(name, itemName);
        values.put(this.expirationDate, expirationDate);
        values.put(this.userId, userId);

        long result = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return result != -1;
    }
    /**
     * Validates the login credentials by checking if the email and password match an existing user.
     *
     * @param email The email entered by the user.
     * @param password The password entered by the user.
     * @return true if the email and password are valid, false otherwise.
     */
    public boolean isValidLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE emailAddress = ? AND password = ?", new String[]{email, password});

        boolean isValid = cursor.getCount() > 0; // If the query returns results, the login is valid

        cursor.close();
        db.close();
        return isValid;
    }


    /**
     * Retrieves all items for a specific user.
     *
     * @param userId The user's ID to retrieve items for.
     * @return A list of Item objects belonging to the user.
     */
    public List<Item> getUserItems(int userId) {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ITEMS + " WHERE " + this.userId + " = ?", new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                Item item = new Item(cursor.getString(cursor.getColumnIndexOrThrow(name)),
                        cursor.getString(cursor.getColumnIndexOrThrow(expirationDate)));
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemList;
    }
    /**
     * Saves a list of items for a specific user to the database.
     * This method is used to bulk insert items if they are stored in memory temporarily.
     *
     * @param userId The user's ID to associate with each item.
     * @param items List of items to save to the database.
     * @return true if all items were successfully saved, false if any insertion failed.
     */
    public boolean saveItems(int userId, List<String> items) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            // Clear existing items for this user before saving new ones
            db.delete(TABLE_ITEMS, userId + " = ?", new String[]{String.valueOf(userId)});

            // Iterate over the list and insert each item
            for (String itemString : items) {
                String[] itemParts = itemString.split(" \\(Expires: | \\(Fresh Produce\\)");

                ContentValues values = new ContentValues();
                values.put(name, itemParts[0]);
                values.put(expirationDate, itemString.contains("Expires:") ? itemParts[1].replace(")", "") : "N/A");
                values.put(this.userId, userId);

                long result = db.insert(TABLE_ITEMS, null, values);
                if (result == -1) {
                    return false; // Insertion failed for one of the items
                }
            }
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
            db.close();
        }
    }


    /**
     * Updates the expiration date of an item for a specific user.
     *
     * @param itemName The name of the item to update.
     * @param newExpirationDate The new expiration date to set.
     * @param userId The ID of the user who owns the item.
     * @return true if the expiration date was successfully updated, false otherwise.
     */
    public boolean updateItemExpiration(String itemName, String newExpirationDate, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(expirationDate, newExpirationDate);

        int rowsUpdated = db.update(TABLE_ITEMS, values, name + " = ? AND " + this.userId + " = ?", new String[]{itemName, String.valueOf(userId)});
        db.close();
        return rowsUpdated > 0;
    }

    /**
     * Deletes an item for a specific user.
     *
     * @param itemName The name of the item to delete.
     * @param userId The ID of the user who owns the item.
     * @return true if the item was successfully deleted, false otherwise.
     */
    public boolean deleteItem(String itemName, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_ITEMS, name + " = ? AND " + this.userId + " = ?", new String[]{itemName, String.valueOf(userId)});
        db.close();
        return rowsDeleted > 0;
    }
    /**
     * Retrieves items that are near expiration for a given date.
     *
     * @param date The date to compare with item expiration dates in the format "yyyy-MM-dd".
     * @return A list of items that are near expiration on or before the specified date.
     */
    public List<Item> getItemsNearExpiration(String date) {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to fetch items where the expiration date is on or before the specified date
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ITEMS + " WHERE " + expirationDate + " <= ?", new String[]{date});

        // Loop through the results and create Item objects
        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(this.name));
                String expiration = cursor.getString(cursor.getColumnIndexOrThrow(this.expirationDate));
                int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(this.item_id));

                Item item = new Item(name, expiration);
                item.setId(itemId); // Set the ID if you need to track it elsewhere
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemList;
    }

}
