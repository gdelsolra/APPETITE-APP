package com.example.finalprojectappetitelab;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText EdtEmailAddressLog, EdtPasswordLog;
    Button btnLoginLog, btnRegisterLog;
    dbConnect dbHelper;

    /**
     * Called when the activity is first created.
     * Initializes the UI components, database helper, and click listeners.
     *
     * @param savedInstanceState Contains data from the activity's previous instance (if any).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize database helper and UI components
        dbHelper = new dbConnect(this);
        EdtEmailAddressLog = findViewById(R.id.username_input);
        EdtPasswordLog = findViewById(R.id.password_input);
        btnLoginLog = findViewById(R.id.login_btn);
        btnRegisterLog = findViewById(R.id.sign_up_btn);

        // Set up listener for the registration button to navigate to RegisterActivity
        btnRegisterLog.setOnClickListener(view -> {
            Intent i = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(i);
        });

        // Set up listener for the login button to handle login
        btnLoginLog.setOnClickListener(view -> handleLogin());

        // Optional: Add a test user for initial testing purposes
        addTestUser();
    }

    /**
     * Handles the login process by checking the entered credentials.
     * If login is successful, navigates to InventoryActivity and passes user ID.
     */
    private void handleLogin() {
        String email = EdtEmailAddressLog.getText().toString().trim();
        String password = EdtPasswordLog.getText().toString().trim();

        // Check for empty fields
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform login check with the database
        if (dbHelper.isValidLogin(email, password)) {
            // Login successful, retrieve user ID and navigate to ExpirationActivity
            int userId = dbHelper.getUserId(email);
            Log.d("LOGIN_DEBUG", "Login successful, navigating to ExpirationActivity");

            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            intent.putExtra("userId", userId); // Pass user ID to ExpirationActivity
            startActivity(intent);

            // Close MainActivity to prevent returning to login after successful login
            finish();
        } else {
            // Display an error message if login failed
            Log.d("LOGIN_DEBUG", "Invalid email or password");
            Toast.makeText(MainActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Adds a test user to the database for initial testing purposes.
     * Ensures that the test user is added only if they don't already exist.
     */
    private void addTestUser() {
        // Check if the test user already exists to avoid duplicates
        if (!dbHelper.isValidLogin("testuser@example.com", "password123")) {
            // Add test user with individual parameters
            boolean isAdded = dbHelper.addUser(
                    "Test User", // Full name
                    "testuser@example.com", // Email
                    "password123", // Password
                    "1234567890" // Phone number
            );

            if (isAdded) {
                Log.d("MainActivity", "Test user added successfully.");
            } else {
                Log.d("MainActivity", "Failed to add test user.");
            }
        } else {
            Log.d("MainActivity", "Test user already exists.");
        }
    }
}

